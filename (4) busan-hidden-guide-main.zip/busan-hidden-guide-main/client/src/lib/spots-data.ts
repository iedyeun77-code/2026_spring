// 부산 숨겨진 관광지 데이터
// 디자인 철학: 해무(海霧) 모더니즘 — 심해 틸 + 테라코타 + 크림 화이트

export type SpotCategory = "자연" | "문화예술" | "역사" | "음식" | "카페" | "액티비티";
export type SpotMood = "힐링" | "감성" | "모험" | "로맨틱" | "역사탐방" | "미식";
export type SpotDuration = "1시간 이내" | "반나절" | "하루";
export type SpotDifficulty = "쉬움" | "보통" | "어려움";

export interface Spot {
  id: string;
  name: string;
  district: string;
  description: string;
  longDescription: string;
  categories: SpotCategory[];
  moods: SpotMood[];
  duration: SpotDuration;
  difficulty: SpotDifficulty;
  bestTime: string;
  tips: string;
  address: string;
  image: string;
  tags: string[];
  hiddenScore: number; // 1-5, 숨겨진 정도
  coordinates: { lat: number; lng: number };
}

export const spots: Spot[] = [
  {
    id: "jeollyeong-trail",
    name: "절영해안산책로",
    district: "영도구",
    description: "대한민국 5대 해안 누리길 중 하나로, 부산 바다의 유려함과 한적함을 동시에 느낄 수 있는 4.8km 해안 산책로",
    longDescription: "영도 남항동에서 태종대까지 연결되는 절영해안산책로는 '무지개 피아노 계단', '출렁다리' 등 특색 있는 포토존과 해안 터널, 파도가 치는 절벽이 어우러진 곳입니다. 모든 계절에 차분한 산책과 사색 여행이 가능하며, 부산 현지인이 평일 저녁 산책을 즐기는 명소입니다.",
    categories: ["자연", "액티비티"],
    moods: ["힐링", "감성"],
    duration: "반나절",
    difficulty: "쉬움",
    bestTime: "일몰 1시간 전",
    tips: "편한 운동화 필수. 해안 터널 구간이 가장 아름다우니 놓치지 마세요.",
    address: "부산시 영도구 절영로",
    image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800",
    tags: ["산책", "해안", "포토존", "일몰"],
    hiddenScore: 4,
    coordinates: { lat: 35.0833, lng: 129.0667 }
  },
  {
    id: "hinyeoul-village",
    name: "흰여울문화마을",
    district: "영도구",
    description: "영도 언덕 골목길을 따라 펼쳐지는 감성 문화마을. 파스텔톤 벽화와 하얀 담장, 그 뒤로 펼쳐지는 푸른 바다",
    longDescription: "영화 '변호인' 촬영지로도 유명한 흰여울문화마을은 한국전쟁 당시 피란민들이 정착하며 형성된 마을입니다. 절벽 위에 자리한 집들 사이로 골목을 걷다 보면 갑자기 탁 트인 바다 전망이 펼쳐집니다. 작은 카페와 갤러리에서 부산만의 낭만을 느낄 수 있습니다.",
    categories: ["문화예술", "역사"],
    moods: ["감성", "로맨틱", "역사탐방"],
    duration: "반나절",
    difficulty: "쉬움",
    bestTime: "오후 2~5시",
    tips: "골목이 좁고 경사가 있으니 편한 신발을 신으세요. 카페 '흰여울'에서 바다를 보며 커피 한 잔을 추천합니다.",
    address: "부산시 영도구 영선동4가",
    image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800",
    tags: ["벽화마을", "골목", "카페", "바다뷰", "사진"],
    hiddenScore: 3,
    coordinates: { lat: 35.0897, lng: 129.0503 }
  },
  {
    id: "ahopsan-forest",
    name: "아홉산숲",
    district: "기장군",
    description: "200년간 비밀스러움을 간직하다 최근 개방된 신비로운 숲. 수령 400년 소나무 군락과 거대한 대나무숲",
    longDescription: "기장군 철마면에 위치한 아홉산숲은 한 가문이 200년 넘게 사유지로 관리해온 원시림입니다. 수령 400년이 넘는 소나무 군락과 거대한 맹종죽 대나무숲, 편백나무 숲이 어우러져 있습니다. 영화 '군도', '대호' 등 수많은 영화와 광고의 촬영지로도 유명합니다.",
    categories: ["자연"],
    moods: ["힐링", "모험"],
    duration: "반나절",
    difficulty: "쉬움",
    bestTime: "이른 아침 (오전 9시 이전)",
    tips: "사전 예약 필수. 대나무숲 구간은 바람 소리가 일품입니다. 모기 기피제 준비 권장.",
    address: "부산시 기장군 철마면 웅천리",
    image: "https://images.unsplash.com/photo-1448375240586-882707db888b?w=800",
    tags: ["대나무숲", "소나무", "피톤치드", "힐링", "촬영지"],
    hiddenScore: 5,
    coordinates: { lat: 35.2667, lng: 129.1833 }
  },
  {
    id: "songdo-cloud-bridge",
    name: "송도 용궁 구름다리",
    district: "서구",
    description: "해수면에서 25m 위를 걷는 127m 아찔한 구름다리. 발아래 철썩이는 파도와 부산 바다의 절경",
    longDescription: "암남공원 내에 위치한 송도 용궁 구름다리는 바다 위를 가로지르는 스릴 넘치는 경험을 선사합니다. 밤이 되면 은은한 조명과 바다가 어우러져 도심 속 별천지가 됩니다. 현지인들이 '관광객보다 부산 사람이 더 자주 찾는 진짜 숨은 명소'라고 부르는 곳입니다.",
    categories: ["자연", "액티비티"],
    moods: ["모험", "로맨틱"],
    duration: "1시간 이내",
    difficulty: "쉬움",
    bestTime: "일몰 후 야경",
    tips: "고소공포증이 있다면 주의. 야간에는 조명이 켜져 더욱 아름답습니다.",
    address: "부산시 서구 암남동 산193",
    image: "https://images.unsplash.com/photo-1545569341-9eb8b30979d9?w=800",
    tags: ["구름다리", "야경", "스릴", "바다뷰"],
    hiddenScore: 4,
    coordinates: { lat: 35.0667, lng: 129.0167 }
  },
  {
    id: "kangkangee-village",
    name: "깡깡이예술마을",
    district: "영도구",
    description: "우리나라 최초 근대식 조선소 터에 조성된 예술마을. 망치질 소리 '깡깡'에서 유래한 이름",
    longDescription: "영도구 대평동에 위치한 깡깡이예술마을은 한국 조선 산업의 모태가 된 곳입니다. 대형 조선소가 떠난 자리에 예술가들이 모여들어 80여 점의 공공 예술 작품을 설치했습니다. 독일 작가 헨드리크 바이키르히의 초대형 그라피티, 네온사인 설치 작품 등이 골목 곳곳에 숨어 있습니다.",
    categories: ["문화예술", "역사"],
    moods: ["감성", "역사탐방"],
    duration: "반나절",
    difficulty: "쉬움",
    bestTime: "오전 10시~오후 4시",
    tips: "마을 안내 지도를 받아 숨겨진 작품을 찾아보세요. 40년 된 양다방에서 쌍화차 한 잔을 추천합니다.",
    address: "부산시 영도구 대평로27번길",
    image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800",
    tags: ["공공미술", "그라피티", "항구", "역사"],
    hiddenScore: 4,
    coordinates: { lat: 35.0917, lng: 129.0417 }
  },
  {
    id: "munhwa-sujung",
    name: "문화공감 수정",
    district: "동구",
    description: "1943년 지어진 일본식 목조 가옥을 찻집으로 운영. 다다미방에서 즐기는 커피와 차",
    longDescription: "문화재청 등록문화재 제330호로 지정된 이곳은 가수 아이유 '밤편지' 뮤직비디오 촬영지로도 유명합니다. 일제강점기 일본인 사업가가 지은 고급 요정이었던 이 건물은 모든 자재를 일본에서 직접 공수했습니다. 현재는 지역 어르신들이 운영하며 따뜻한 분위기를 자아냅니다.",
    categories: ["역사", "카페"],
    moods: ["감성", "역사탐방"],
    duration: "1시간 이내",
    difficulty: "쉬움",
    bestTime: "평일 오전",
    tips: "음료 수익금이 건물 관리에 사용됩니다. 볕이 잘 드는 마루가 최고의 포토 스폿입니다.",
    address: "부산시 동구 홍곡로 75",
    image: "https://images.unsplash.com/photo-1528360983277-13d401cdc186?w=800",
    tags: ["일본식가옥", "찻집", "문화재", "감성카페"],
    hiddenScore: 5,
    coordinates: { lat: 35.1167, lng: 129.0417 }
  },
  {
    id: "jeonpo-cafe-street",
    name: "전포 카페 거리",
    district: "부산진구",
    description: "서면 번화가 뒤편에 숨겨진 개성 넘치는 카페 골목. 커피 박물관과 독립 카페들의 집합소",
    longDescription: "전포동 카페 거리는 서면의 화려함에 가려진 부산의 숨은 카페 성지입니다. 각기 다른 콘셉트의 독립 카페들이 좁은 골목을 따라 늘어서 있으며, 무료로 방문할 수 있는 커피 박물관도 있습니다. 로스터리 카페부터 빈티지 소품 카페까지 다양한 취향을 만족시킵니다.",
    categories: ["카페"],
    moods: ["감성", "힐링"],
    duration: "반나절",
    difficulty: "쉬움",
    bestTime: "오후 1~5시",
    tips: "주말에는 주차가 어려우니 대중교통 이용을 권장합니다. 커피 박물관은 무료입니다.",
    address: "부산시 부산진구 전포동",
    image: "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=800",
    tags: ["카페", "커피", "골목", "독립카페"],
    hiddenScore: 3,
    coordinates: { lat: 35.1583, lng: 129.0583 }
  },
  {
    id: "dadaepo-beach",
    name: "다대포 해수욕장",
    district: "사하구",
    description: "인파 없이 평화로운 해변과 환상적인 일몰. 음악 분수 쇼와 드넓은 모래사장",
    longDescription: "부산의 대표 해수욕장인 해운대와 광안리에 비해 훨씬 한적한 다대포 해수욕장은 현지인들이 즐겨 찾는 숨은 명소입니다. 드넓은 모래사장과 맑고 얕은 바다, 그리고 갈대밭이 어우러진 낙동강 하구는 특히 일몰 때 황홀한 풍경을 선사합니다.",
    categories: ["자연"],
    moods: ["힐링", "로맨틱"],
    duration: "반나절",
    difficulty: "쉬움",
    bestTime: "일몰 시간대",
    tips: "여름 성수기에도 해운대보다 훨씬 한적합니다. 음악 분수 공연 시간을 미리 확인하세요.",
    address: "부산시 사하구 다대동",
    image: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800",
    tags: ["해수욕장", "일몰", "분수쇼", "갈대"],
    hiddenScore: 3,
    coordinates: { lat: 35.0500, lng: 128.9667 }
  },
  {
    id: "cheongsapo-skywalk",
    name: "청사포 다릿돌 전망대",
    district: "해운대구",
    description: "해발 20m, 길이 72m의 해양 스카이워크. 발아래 파도와 동해의 장엄한 경치",
    longDescription: "청사포(靑蛇浦, 푸른 뱀 포구)에 위치한 이 스카이워크는 마치 큰 뱀이 해안을 미끄러지듯 뻗어 있습니다. 투명한 유리 바닥 아래로 파도가 바위에 부딪히는 장면을 볼 수 있으며, 해운대 블루라인파크 열차와 함께 방문하면 더욱 즐겁습니다.",
    categories: ["자연", "액티비티"],
    moods: ["모험", "감성"],
    duration: "1시간 이내",
    difficulty: "쉬움",
    bestTime: "맑은 날 오전",
    tips: "해운대 블루라인파크 해변열차와 연계하면 좋습니다. 일출 명소로도 유명합니다.",
    address: "부산시 해운대구 청사포로",
    image: "https://images.unsplash.com/photo-1519451241324-20b4ea2c4220?w=800",
    tags: ["스카이워크", "전망대", "파도", "일출"],
    hiddenScore: 3,
    coordinates: { lat: 35.1667, lng: 129.2000 }
  },
  {
    id: "amnam-park",
    name: "암남공원",
    district: "서구",
    description: "해안 절벽과 소나무 숲이 어우러진 현지인의 바다 트레킹 성지. 두도 섬 전망과 청정 해안",
    longDescription: "서구 암남동에 위치한 암남공원은 비교적 덜 알려진 부산의 자연 명소입니다. 임해산책로와 생태탐방로를 따라 걸으며 도시의 번잡함을 잊을 수 있습니다. 전망대에서는 무인 자연 보호구역인 두도 섬을 볼 수 있으며, 공원 끝에서 송도 해수욕장으로 이어집니다.",
    categories: ["자연", "액티비티"],
    moods: ["힐링", "모험"],
    duration: "반나절",
    difficulty: "보통",
    bestTime: "오전 9~11시",
    tips: "등산화 또는 트레킹화 착용 권장. 공원 내 화장실이 적으니 미리 준비하세요.",
    address: "부산시 서구 암남동 산193",
    image: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=800",
    tags: ["트레킹", "소나무숲", "전망대", "해안"],
    hiddenScore: 4,
    coordinates: { lat: 35.0583, lng: 129.0083 }
  },
  {
    id: "dongrae-pajeon",
    name: "동래할매파전",
    district: "동래구",
    description: "70년 전통의 동래파전 원조. 조선 시대 임금에게 진상하던 파전의 맥을 잇는 곳",
    longDescription: "동래구청 뒤쪽에 자리한 동래할매파전은 같은 자리에서 40여 년을 영업한 부산의 살아있는 역사입니다. 쪽파를 나란히 길게 늘어놓아 쌓는 독특한 방식과 굴, 새우, 대합, 홍합 등 신선한 해산물을 듬뿍 넣는 것이 특징입니다. 막걸리와 함께 즐기는 것이 정석입니다.",
    categories: ["음식"],
    moods: ["미식", "역사탐방"],
    duration: "1시간 이내",
    difficulty: "쉬움",
    bestTime: "저녁 식사 시간",
    tips: "초장에 찍어 먹는 것이 정통 방식입니다. 막걸리 한 사발과 함께하면 금상첨화.",
    address: "부산시 동래구 명륜로94번길 43-10",
    image: "https://images.unsplash.com/photo-1563245372-f21724e3856d?w=800",
    tags: ["파전", "전통음식", "막걸리", "노포"],
    hiddenScore: 3,
    coordinates: { lat: 35.2000, lng: 129.0833 }
  },
  {
    id: "sanbok-road",
    name: "산복도로 전망대",
    district: "동구/서구",
    description: "한국전쟁 피란민의 삶이 녹아있는 산중턱 도로. 부산 도심과 항구를 한눈에 내려다보는 절경",
    longDescription: "부산의 산복도로는 6.25 전쟁 당시 피란민들이 산 중턱에 집을 짓고 살면서 만들어진 길입니다. 현재는 부산의 역사와 현재가 공존하는 독특한 문화 경관으로 주목받고 있습니다. '누리바라기' 전망대에서는 부산타워부터 영도까지 파노라마 뷰를 감상할 수 있습니다.",
    categories: ["역사", "문화예술"],
    moods: ["역사탐방", "감성"],
    duration: "반나절",
    difficulty: "보통",
    bestTime: "야경 감상 시",
    tips: "168계단 모노레일을 타면 쉽게 올라갈 수 있습니다. 야경이 특히 아름답습니다.",
    address: "부산시 동구 초량동 일대",
    image: "https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?w=800",
    tags: ["야경", "전망대", "역사", "피란민"],
    hiddenScore: 4,
    coordinates: { lat: 35.1167, lng: 129.0500 }
  }
];

// 취향 설문 질문 데이터
export interface QuizQuestion {
  id: string;
  question: string;
  subtitle: string;
  type: "single" | "multi" | "slider";
  options?: QuizOption[];
  min?: number;
  max?: number;
  minLabel?: string;
  maxLabel?: string;
}

export interface QuizOption {
  id: string;
  label: string;
  emoji: string;
  description?: string;
  value: string;
}

export const quizQuestions: QuizQuestion[] = [
  {
    id: "travel-style",
    question: "어떤 여행을 꿈꾸시나요?",
    subtitle: "당신의 여행 스타일을 알려주세요",
    type: "single",
    options: [
      { id: "healing", label: "조용한 힐링", emoji: "🌊", description: "바다 소리를 들으며 마음을 비우는 여행", value: "힐링" },
      { id: "culture", label: "감성 문화 탐방", emoji: "🎨", description: "예술과 역사가 살아숨쉬는 골목 여행", value: "감성" },
      { id: "adventure", label: "짜릿한 모험", emoji: "⛰️", description: "새로운 경험과 스릴을 찾는 여행", value: "모험" },
      { id: "romantic", label: "로맨틱한 데이트", emoji: "🌅", description: "특별한 추억을 만드는 여행", value: "로맨틱" },
      { id: "history", label: "역사 탐험", emoji: "🏛️", description: "부산의 깊은 역사를 따라가는 여행", value: "역사탐방" },
      { id: "food", label: "미식 탐방", emoji: "🍜", description: "부산의 숨겨진 맛을 찾아가는 여행", value: "미식" }
    ]
  },
  {
    id: "companion",
    question: "누구와 함께 여행하시나요?",
    subtitle: "동행에 따라 최적의 코스를 추천해드릴게요",
    type: "single",
    options: [
      { id: "solo", label: "혼자", emoji: "🚶", description: "나만의 시간을 즐기는 솔로 여행", value: "solo" },
      { id: "couple", label: "연인과 함께", emoji: "💑", description: "둘만의 특별한 시간", value: "couple" },
      { id: "friends", label: "친구들과", emoji: "👫", description: "즐거운 추억을 함께 만드는 여행", value: "friends" },
      { id: "family", label: "가족과 함께", emoji: "👨‍👩‍👧", description: "온 가족이 즐길 수 있는 여행", value: "family" }
    ]
  },
  {
    id: "duration",
    question: "여행 기간은 얼마나 되나요?",
    subtitle: "일정에 맞는 코스를 구성해드릴게요",
    type: "single",
    options: [
      { id: "half-day", label: "반나절", emoji: "⏰", description: "3~4시간의 짧은 여행", value: "반나절" },
      { id: "one-day", label: "하루", emoji: "☀️", description: "알차게 하루를 보내는 여행", value: "하루" },
      { id: "two-days", label: "1박 2일", emoji: "🌙", description: "여유롭게 부산을 즐기는 여행", value: "1박2일" },
      { id: "three-days", label: "2박 3일 이상", emoji: "🗓️", description: "부산의 구석구석을 탐험하는 여행", value: "2박3일이상" }
    ]
  },
  {
    id: "categories",
    question: "어떤 종류의 장소를 선호하시나요?",
    subtitle: "복수 선택 가능합니다",
    type: "multi",
    options: [
      { id: "nature", label: "자연·해안", emoji: "🌿", value: "자연" },
      { id: "culture", label: "문화·예술", emoji: "🎭", value: "문화예술" },
      { id: "history", label: "역사·건축", emoji: "🏯", value: "역사" },
      { id: "food", label: "음식·맛집", emoji: "🍱", value: "음식" },
      { id: "cafe", label: "카페·디저트", emoji: "☕", value: "카페" },
      { id: "activity", label: "액티비티", emoji: "🏃", value: "액티비티" }
    ]
  },
  {
    id: "activity-level",
    question: "얼마나 활동적인 여행을 원하시나요?",
    subtitle: "체력 소모 정도를 알려주세요",
    type: "slider",
    min: 1,
    max: 3,
    minLabel: "편안하게 쉬고 싶어요",
    maxLabel: "활동적으로 즐기고 싶어요"
  }
];

// 추천 로직
export interface UserPreferences {
  travelStyle: string;
  companion: string;
  duration: string;
  categories: string[];
  activityLevel: number;
}

export function getRecommendations(prefs: UserPreferences): Spot[] {
  const scored = spots.map(spot => {
    let score = 0;

    // 여행 스타일 매칭
    if (spot.moods.includes(prefs.travelStyle as SpotMood)) score += 30;

    // 카테고리 매칭
    const catMatches = spot.categories.filter(c => prefs.categories.includes(c)).length;
    score += catMatches * 20;

    // 활동 레벨 매칭
    const difficultyMap = { "쉬움": 1, "보통": 2, "어려움": 3 };
    const diffScore = difficultyMap[spot.difficulty];
    if (Math.abs(diffScore - prefs.activityLevel) === 0) score += 15;
    else if (Math.abs(diffScore - prefs.activityLevel) === 1) score += 8;

    // 동행 유형 보너스
    if (prefs.companion === "couple" && spot.moods.includes("로맨틱")) score += 10;
    if (prefs.companion === "solo" && spot.moods.includes("힐링")) score += 10;
    if (prefs.companion === "family" && spot.difficulty === "쉬움") score += 10;

    // 숨겨진 정도 가중치 (숨겨진 곳일수록 더 높은 점수)
    score += spot.hiddenScore * 3;

    return { spot, score };
  });

  return scored
    .sort((a, b) => b.score - a.score)
    .slice(0, 6)
    .map(s => s.spot);
}

// 프로그램북 일정 생성
export interface ItineraryItem {
  time: string;
  spot: Spot;
  activity: string;
  tip: string;
}

export function generateItinerary(spots: Spot[], duration: string): ItineraryItem[] {
  const times = ["09:00", "11:00", "13:00", "15:00", "17:00", "19:00"];
  const activities = [
    "도착 및 주변 탐색",
    "본격 관람 및 체험",
    "점심 식사 및 휴식",
    "오후 산책 및 감상",
    "일몰 감상",
    "저녁 식사 및 마무리"
  ];

  const maxSpots = duration === "반나절" ? 2 : duration === "하루" ? 4 : 6;
  const selectedSpots = spots.slice(0, maxSpots);

  return selectedSpots.map((spot, i) => ({
    time: times[i] || times[times.length - 1],
    spot,
    activity: activities[i] || activities[activities.length - 1],
    tip: spot.tips
  }));
}
