/* =============================================================
   Quiz.tsx — 취향 설문 페이지
   Design: 해무(海霧) 모더니즘
   - 전체화면 몰입형 설문
   - 단계별 진행 인디케이터
   - 부드러운 슬라이드 전환
   ============================================================= */

import { useState, useCallback } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight, Check, Minus, Plus } from "lucide-react";
import { quizQuestions, type UserPreferences } from "@/lib/spots-data";

const slideVariants = {
  enter: (direction: number) => ({
    x: direction > 0 ? 60 : -60,
    opacity: 0,
  }),
  center: {
    x: 0,
    opacity: 1,
  },
  exit: (direction: number) => ({
    x: direction < 0 ? 60 : -60,
    opacity: 0,
  }),
};

export default function Quiz() {
  const [, navigate] = useLocation();
  const [currentStep, setCurrentStep] = useState(0);
  const [direction, setDirection] = useState(1);
  const [answers, setAnswers] = useState<Record<string, string | string[] | number>>({
    "activity-level": 2, // 슬라이더 기본값
  });

  const question = quizQuestions[currentStep];
  const totalSteps = quizQuestions.length;
  const progress = ((currentStep + 1) / totalSteps) * 100;
  const currentAnswer = answers[question.id];

  // 현재 단계의 답변 여부 확인
  const isCurrentAnswered = useCallback(() => {
    if (question.type === "single") {
      return !!currentAnswer && currentAnswer !== "";
    }
    if (question.type === "multi") {
      return Array.isArray(currentAnswer) && currentAnswer.length > 0;
    }
    if (question.type === "slider") {
      return currentAnswer !== undefined && currentAnswer !== null;
    }
    return false;
  }, [currentAnswer, question.type]);

  const handleSingleSelect = (value: string) => {
    setAnswers(prev => ({ ...prev, [question.id]: value }));
  };

  const handleMultiSelect = (value: string) => {
    const current = (answers[question.id] as string[]) || [];
    const updated = current.includes(value)
      ? current.filter(v => v !== value)
      : [...current, value];
    setAnswers(prev => ({ ...prev, [question.id]: updated }));
  };

  const handleSlider = (value: number) => {
    setAnswers(prev => ({ ...prev, [question.id]: value }));
  };

  const handleNext = useCallback(() => {
    // 현재 단계 답변 확인
    if (!isCurrentAnswered()) {
      console.warn("답변이 선택되지 않았습니다");
      return;
    }

    if (currentStep < totalSteps - 1) {
      setDirection(1);
      setCurrentStep(prev => prev + 1);
    } else {
      // 결과 페이지로 이동
      const prefs: UserPreferences = {
        travelStyle: (answers["travel-style"] as string) || "힐링",
        companion: (answers["companion"] as string) || "solo",
        duration: (answers["duration"] as string) || "하루",
        categories: (answers["categories"] as string[]) || [],
        activityLevel: (answers["activity-level"] as number) || 2,
      };
      sessionStorage.setItem("busan-quiz-result", JSON.stringify(prefs));
      navigate("/result");
    }
  }, [currentStep, totalSteps, isCurrentAnswered, answers, navigate]);

  const handlePrev = useCallback(() => {
    if (currentStep > 0) {
      setDirection(-1);
      setCurrentStep(prev => prev - 1);
    } else {
      navigate("/");
    }
  }, [currentStep, navigate]);

  const sliderValue = (answers["activity-level"] as number) ?? 2;

  return (
    <div className="min-h-screen bg-[oklch(0.97_0.01_80)] flex flex-col">
      {/* 상단 헤더 */}
      <header className="flex items-center justify-between px-6 py-4 bg-white border-b border-[oklch(0.87_0.02_80)]">
        <button
          onClick={handlePrev}
          className="flex items-center gap-1.5 text-[oklch(0.52_0.02_200)] hover:text-[oklch(0.32_0.07_210)] transition-colors text-sm font-medium"
        >
          <ChevronLeft className="w-4 h-4" />
          {currentStep === 0 ? "홈으로" : "이전"}
        </button>

        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-full bg-[oklch(0.32_0.07_210)] flex items-center justify-center">
            <span className="text-white text-[10px] font-bold" style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>부</span>
          </div>
          <span className="text-[oklch(0.32_0.07_210)] font-bold text-sm" style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>
            취향 설문
          </span>
        </div>

        <span className="text-[oklch(0.52_0.02_200)] text-sm font-medium">
          {currentStep + 1} / {totalSteps}
        </span>
      </header>

      {/* 진행 바 */}
      <div className="h-1 bg-[oklch(0.87_0.02_80)]">
        <motion.div
          className="h-full bg-[oklch(0.32_0.07_210)]"
          animate={{ width: `${progress}%` }}
          transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
        />
      </div>

      {/* 설문 콘텐츠 */}
      <div className="flex-1 flex flex-col items-center justify-center px-4 py-8">
        <div className="w-full max-w-2xl">
          {/* 단계 인디케이터 */}
          <div className="flex items-center justify-center gap-2 mb-8">
            {quizQuestions.map((_, i) => (
              <div
                key={i}
                className={`step-indicator ${i === currentStep ? 'active' : i < currentStep ? 'completed' : ''}`}
              />
            ))}
          </div>

          <AnimatePresence mode="wait" custom={direction}>
            <motion.div
              key={currentStep}
              custom={direction}
              variants={slideVariants}
              initial="enter"
              animate="center"
              exit="exit"
              transition={{ duration: 0.35, ease: [0.23, 1, 0.32, 1] }}
            >
              {/* 질문 */}
              <div className="text-center mb-10">
                <p className="text-[oklch(0.58_0.12_45)] font-bold text-xs tracking-widest uppercase mb-2"
                  style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>
                  Step {currentStep + 1}
                </p>
                <h2 className="text-3xl md:text-4xl font-bold text-[oklch(0.22_0.01_240)] mb-3"
                  style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>
                  {question.question}
                </h2>
                <p className="text-[oklch(0.52_0.02_200)] text-base"
                  style={{ fontFamily: "'Noto Serif KR', serif" }}>
                  {question.subtitle}
                </p>
              </div>

              {/* 단일 선택 */}
              {question.type === "single" && (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {question.options?.map((option) => (
                    <motion.button
                      key={option.id}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.97 }}
                      onClick={() => handleSingleSelect(option.value)}
                      className={`busan-option-card text-left relative ${
                        currentAnswer === option.value ? "selected" : ""
                      }`}
                    >
                      {currentAnswer === option.value && (
                        <div className="absolute top-3 right-3 w-5 h-5 rounded-full bg-[oklch(0.32_0.07_210)] flex items-center justify-center">
                          <Check className="w-3 h-3 text-white" />
                        </div>
                      )}
                      <div className="text-3xl mb-2">{option.emoji}</div>
                      <p className="font-bold text-[oklch(0.22_0.01_240)] text-sm mb-1"
                        style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>
                        {option.label}
                      </p>
                      {option.description && (
                        <p className="text-[oklch(0.52_0.02_200)] text-xs leading-relaxed">
                          {option.description}
                        </p>
                      )}
                    </motion.button>
                  ))}
                </div>
              )}

              {/* 다중 선택 */}
              {question.type === "multi" && (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {question.options?.map((option) => {
                    const selected = Array.isArray(currentAnswer) && currentAnswer.includes(option.value);
                    return (
                      <motion.button
                        key={option.id}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.97 }}
                        onClick={() => handleMultiSelect(option.value)}
                        className={`busan-option-card text-center relative ${selected ? "selected" : ""}`}
                      >
                        {selected && (
                          <div className="absolute top-3 right-3 w-5 h-5 rounded-full bg-[oklch(0.32_0.07_210)] flex items-center justify-center">
                            <Check className="w-3 h-3 text-white" />
                          </div>
                        )}
                        <div className="text-3xl mb-2">{option.emoji}</div>
                        <p className="font-bold text-[oklch(0.22_0.01_240)] text-sm"
                          style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>
                          {option.label}
                        </p>
                      </motion.button>
                    );
                  })}
                </div>
              )}

              {/* 슬라이더 */}
              {question.type === "slider" && (
                <div className="bg-white rounded-2xl p-8 shadow-sm border border-[oklch(0.87_0.02_80)]">
                  <div className="flex items-center justify-between mb-6">
                    <span className="text-sm text-[oklch(0.52_0.02_200)] max-w-[120px] text-center">{question.minLabel}</span>
                    <div className="flex items-center gap-6">
                      <button
                        onClick={() => handleSlider(Math.max(1, sliderValue - 1))}
                        className="w-10 h-10 rounded-full border-2 border-[oklch(0.87_0.02_80)] flex items-center justify-center hover:border-[oklch(0.32_0.07_210)] transition-colors"
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <div className="text-center">
                        <div className="text-4xl font-bold text-[oklch(0.32_0.07_210)]"
                          style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>
                          {sliderValue === 1 ? "😌" : sliderValue === 2 ? "🚶" : "🏃"}
                        </div>
                        <p className="text-sm text-[oklch(0.52_0.02_200)] mt-1">
                          {sliderValue === 1 ? "여유롭게" : sliderValue === 2 ? "적당히" : "활동적으로"}
                        </p>
                      </div>
                      <button
                        onClick={() => handleSlider(Math.min(3, sliderValue + 1))}
                        className="w-10 h-10 rounded-full border-2 border-[oklch(0.87_0.02_80)] flex items-center justify-center hover:border-[oklch(0.32_0.07_210)] transition-colors"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                    <span className="text-sm text-[oklch(0.52_0.02_200)] max-w-[120px] text-center">{question.maxLabel}</span>
                  </div>

                  {/* 시각적 슬라이더 바 */}
                  <div className="flex gap-2 mt-4">
                    {[1, 2, 3].map((v) => (
                      <button
                        key={v}
                        onClick={() => handleSlider(v)}
                        className={`flex-1 h-3 rounded-full transition-all duration-200 ${
                          v <= sliderValue
                            ? "bg-[oklch(0.32_0.07_210)]"
                            : "bg-[oklch(0.87_0.02_80)]"
                        }`}
                      />
                    ))}
                  </div>
                </div>
              )}
            </motion.div>
          </AnimatePresence>

          {/* 다음 버튼 */}
          <div className="mt-8 flex justify-center">
            <motion.button
              whileHover={isCurrentAnswered() ? { scale: 1.02, y: -2 } : {}}
              whileTap={isCurrentAnswered() ? { scale: 0.97 } : {}}
              onClick={handleNext}
              disabled={!isCurrentAnswered()}
              className={`inline-flex items-center gap-2 px-10 py-4 rounded-full font-bold text-lg transition-all ${
                isCurrentAnswered()
                  ? "bg-[oklch(0.32_0.07_210)] text-white shadow-lg shadow-[oklch(0.32_0.07_210)]/20 cursor-pointer"
                  : "bg-[oklch(0.87_0.02_80)] text-[oklch(0.52_0.02_200)] cursor-not-allowed opacity-50"
              }`}
              style={{ fontFamily: "'Gmarket Sans', sans-serif" }}
            >
              {currentStep === totalSteps - 1 ? "결과 보기" : "다음"}
              <ChevronRight className="w-5 h-5" />
            </motion.button>
          </div>
        </div>
      </div>
    </div>
  );
}
