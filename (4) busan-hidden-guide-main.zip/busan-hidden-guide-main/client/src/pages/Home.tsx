/* =============================================================
   Home.tsx — 랜딩 페이지
   Design: 해무(海霧) 모더니즘
   - 히어로: 부산 새벽 안개 이미지 + 강렬한 타이포그래피
   - 소개: 서비스 특징 3가지
   - CTA: 취향 설문 시작 버튼
   ============================================================= */

import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { MapPin, Compass, BookOpen, ChevronDown, Sparkles } from "lucide-react";

const HERO_IMAGE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663741628982/8k7uBbEkKxuaBLhtK7jFk7/hero-busan-mist-GfjcHPDtMgJwhuoMz9Y6F7.webp";
const COASTAL_IMAGE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663741628982/8k7uBbEkKxuaBLhtK7jFk7/busan-coastal-walk-o6pxiCsDKzyjcScA8xXeb6.webp";
const ALLEY_IMAGE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663741628982/8k7uBbEkKxuaBLhtK7jFk7/busan-alley-culture-3pNCMyZQPfGE4msHbjQajg.webp";
const BOOK_IMAGE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663741628982/8k7uBbEkKxuaBLhtK7jFk7/busan-programbook-cover-2qTtRk2F3DMivoJ7ErKTNV.webp";

const features = [
  {
    icon: Compass,
    title: "취향 맞춤 추천",
    description: "여행 스타일, 동행, 기간을 분석해 당신만을 위한 숨겨진 명소를 골라드립니다",
    color: "text-[oklch(0.32_0.07_210)]"
  },
  {
    icon: MapPin,
    title: "현지인 비밀 스폿",
    description: "해운대·광안리를 넘어 진짜 부산 사람들이 아끼는 12곳의 숨은 명소",
    color: "text-[oklch(0.58_0.12_45)]"
  },
  {
    icon: BookOpen,
    title: "나만의 프로그램북",
    description: "추천된 장소들로 구성된 개인화 여행 일정표를 바로 출력·저장하세요",
    color: "text-[oklch(0.62_0.07_175)]"
  }
];

const hiddenSpots = [
  { name: "절영해안산책로", tag: "자연·힐링", district: "영도구" },
  { name: "아홉산숲", tag: "자연 힐링", district: "기장군" },
  { name: "깡깡이예술마을", tag: "문화예술", district: "영도구" },
  { name: "문화공감 수정", tag: "역사·카페", district: "동구" },
  { name: "전포 카페 거리", tag: "카페", district: "부산진구" },
  { name: "산복도로 전망대", tag: "야경·역사", district: "동구" },
];

export default function Home() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-[oklch(0.97_0.01_80)]">
      {/* 네비게이션 */}
      <nav className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 py-4 bg-[oklch(0.97_0.01_80)]/80 backdrop-blur-md border-b border-[oklch(0.87_0.02_80)]">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-[oklch(0.32_0.07_210)] flex items-center justify-center">
            <span className="text-white text-xs font-bold" style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>부</span>
          </div>
          <span className="font-bold text-[oklch(0.32_0.07_210)] text-sm" style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>
            부산 숨은 여행
          </span>
        </div>
        <button
          onClick={() => navigate("/quiz")}
          className="busan-btn-primary text-sm px-5 py-2 rounded-full"
          style={{ fontFamily: "'Gmarket Sans', sans-serif" }}
        >
          여행 시작하기
        </button>
      </nav>

      {/* 히어로 섹션 */}
      <section className="relative min-h-screen flex items-center overflow-hidden">
        {/* 배경 이미지 */}
        <div className="absolute inset-0">
          <img
            src={HERO_IMAGE}
            alt="부산 새벽 안개"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[oklch(0.22_0.01_240)]/80 via-[oklch(0.22_0.01_240)]/50 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-[oklch(0.22_0.01_240)]/60 via-transparent to-transparent" />
        </div>

        {/* 히어로 콘텐츠 */}
        <div className="relative z-10 container pt-24 pb-16">
          <div className="max-w-2xl">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, ease: [0.23, 1, 0.32, 1] }}
            >
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-white leading-tight mb-6"
                style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>
                나만의<br />
                <span className="text-[oklch(0.72_0.09_45)]">부산</span>을<br />
                발견하다
              </h1>

              <p className="text-white/80 text-lg md:text-xl leading-relaxed mb-8 max-w-lg"
                style={{ fontFamily: "'Noto Serif KR', serif" }}>
                부산 현지인이 아끼는 숨겨진 명소들.<br />
                당신의 취향에 맞는 특별한 여행 코스를 만들어드립니다.
              </p>

              <div className="flex flex-col sm:flex-row gap-4">
                <motion.button
                  whileHover={{ scale: 1.02, y: -2 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => navigate("/quiz")}
                  className="inline-flex items-center justify-center gap-2 bg-[oklch(0.58_0.12_45)] text-white font-bold px-8 py-4 rounded-full text-lg shadow-lg shadow-[oklch(0.58_0.12_45)]/30 transition-all"
                  style={{ fontFamily: "'Gmarket Sans', sans-serif" }}
                >
                  <Compass className="w-5 h-5" />
                  취향 설문 시작하기
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.02, y: -2 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })}
                  className="inline-flex items-center justify-center gap-2 bg-white/10 backdrop-blur-sm border border-white/30 text-white font-medium px-8 py-4 rounded-full text-lg transition-all hover:bg-white/20"
                >
                  더 알아보기
                  <ChevronDown className="w-5 h-5" />
                </motion.button>
              </div>
            </motion.div>
          </div>
        </div>

        {/* 스크롤 인디케이터 */}
        <motion.div
          className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
          animate={{ y: [0, 8, 0] }}
          transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
        >
          <div className="w-px h-12 bg-gradient-to-b from-transparent to-white/50" />
          <ChevronDown className="w-4 h-4 text-white/50" />
        </motion.div>
      </section>

      {/* 특징 섹션 */}
      <section id="features" className="py-24 bg-white">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: [0.23, 1, 0.32, 1] }}
            className="text-center mb-16"
          >
            <p className="text-[oklch(0.58_0.12_45)] font-bold text-sm tracking-widest uppercase mb-3"
              style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>
              How It Works
            </p>
            <h2 className="text-4xl md:text-5xl font-bold text-[oklch(0.22_0.01_240)] mb-4"
              style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>
              세 단계로 완성되는<br />나만의 부산 여행
            </h2>
            <p className="text-[oklch(0.52_0.02_200)] text-lg max-w-xl mx-auto"
              style={{ fontFamily: "'Noto Serif KR', serif" }}>
              취향을 알려주시면, 당신에게 꼭 맞는 숨겨진 부산을 찾아드립니다
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, i) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.1, ease: [0.23, 1, 0.32, 1] }}
                className="busan-card p-8 text-center"
              >
                <div className={`inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-[oklch(0.97_0.01_80)] mb-5 ${feature.color}`}>
                  <feature.icon className="w-7 h-7" />
                </div>
                <h3 className="text-xl font-bold text-[oklch(0.22_0.01_240)] mb-3"
                  style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>
                  {feature.title}
                </h3>
                <p className="text-[oklch(0.52_0.02_200)] leading-relaxed text-sm">
                  {feature.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 숨겨진 명소 미리보기 */}
      <section className="py-24 bg-[oklch(0.97_0.01_80)] dot-pattern">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* 텍스트 */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, ease: [0.23, 1, 0.32, 1] }}
            >
              <p className="text-[oklch(0.58_0.12_45)] font-bold text-sm tracking-widest uppercase mb-3"
                style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>
                Hidden Gems
              </p>
              <h2 className="text-4xl md:text-5xl font-bold text-[oklch(0.22_0.01_240)] mb-6 leading-tight"
                style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>
                아직 아무도 모르는<br />
                부산
              </h2>
              <p className="text-[oklch(0.52_0.02_200)] text-lg leading-relaxed mb-8"
                style={{ fontFamily: "'Noto Serif KR', serif" }}>
                200년 된 비밀 숲, 피란민의 삶이 녹아있는 산복도로,<br />
                일제강점기 목조 가옥의 찻집까지.<br />
                부산의 진짜 얼굴을 만나보세요.
              </p>

              <div className="grid grid-cols-2 gap-3 mb-8">
                {hiddenSpots.map((spot, i) => (
                  <motion.div
                    key={spot.name}
                    initial={{ opacity: 0, scale: 0.95 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.05, duration: 0.4 }}
                    className="bg-white rounded-xl p-3 border border-[oklch(0.87_0.02_80)] hover:border-[oklch(0.32_0.07_210)]/30 transition-colors"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="font-bold text-[oklch(0.22_0.01_240)] text-sm"
                          style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>
                          {spot.name}
                        </p>
                        <p className="text-[oklch(0.52_0.02_200)] text-xs mt-0.5">{spot.district}</p>
                      </div>
                      <span className="hidden-score-badge whitespace-nowrap">{spot.tag}</span>
                    </div>
                  </motion.div>
                ))}
              </div>

              <motion.button
                whileHover={{ scale: 1.02, y: -2 }}
                whileTap={{ scale: 0.97 }}
                onClick={() => navigate("/quiz")}
                className="busan-btn-primary inline-flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4" />
                내 취향으로 찾아보기
              </motion.button>
            </motion.div>

            {/* 이미지 콜라주 */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, ease: [0.23, 1, 0.32, 1] }}
              className="relative"
            >
              <div className="relative grid grid-cols-2 gap-4">
                <div className="space-y-4">
                  <div className="porthole-image w-full aspect-square overflow-hidden rounded-2xl">
                    <img src={ALLEY_IMAGE} alt="감천문화마을" className="w-full h-full object-cover" />
                  </div>
                  <div className="bg-[oklch(0.32_0.07_210)] rounded-2xl p-5 text-white">
                    <p className="text-3xl font-bold mb-1" style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>12곳</p>
                    <p className="text-white/70 text-sm">숨겨진 명소</p>
                  </div>
                </div>
                <div className="space-y-4 mt-8">
                  <div className="bg-[oklch(0.58_0.12_45)] rounded-2xl p-5 text-white">
                    <p className="text-3xl font-bold mb-1" style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>5분</p>
                    <p className="text-white/70 text-sm">설문 완성</p>
                  </div>
                  <div className="rounded-2xl overflow-hidden">
                    <img src={COASTAL_IMAGE} alt="절영해안산책로" className="w-full aspect-[3/4] object-cover" />
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* 프로그램북 미리보기 섹션 */}
      <section className="py-24 bg-[oklch(0.32_0.07_210)]">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* 책 이미지 */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="flex justify-center"
            >
              <div className="relative">
                <div className="absolute -inset-4 bg-white/5 rounded-3xl blur-xl" />
                <img
                  src={BOOK_IMAGE}
                  alt="부산 여행 프로그램북"
                  className="relative w-64 md:w-80 rounded-2xl shadow-2xl shadow-black/30"
                />
              </div>
            </motion.div>

            {/* 텍스트 */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, ease: [0.23, 1, 0.32, 1] }}
            >
              <p className="text-[oklch(0.72_0.09_45)] font-bold text-sm tracking-widest uppercase mb-3"
                style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>
                Program Book
              </p>
              <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 leading-tight"
                style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>
                나만의 여행<br />프로그램북 완성
              </h2>
              <p className="text-white/70 text-lg leading-relaxed mb-8"
                style={{ fontFamily: "'Noto Serif KR', serif" }}>
                추천된 장소들로 구성된 시간대별 여행 일정표.
                각 장소의 꿀팁, 최적 방문 시간, 교통 정보까지
                한 권에 담아드립니다.
              </p>

              <div className="space-y-3 mb-8">
                {["시간대별 최적 동선 구성", "각 장소별 현지인 꿀팁", "인쇄·저장 가능한 PDF 형식"].map((item, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <div className="w-5 h-5 rounded-full bg-[oklch(0.72_0.09_45)] flex items-center justify-center flex-shrink-0">
                      <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <span className="text-white/80 text-sm">{item}</span>
                  </div>
                ))}
              </div>

              <motion.button
                whileHover={{ scale: 1.02, y: -2 }}
                whileTap={{ scale: 0.97 }}
                onClick={() => navigate("/quiz")}
                className="inline-flex items-center gap-2 bg-[oklch(0.58_0.12_45)] text-white font-bold px-8 py-4 rounded-full text-lg shadow-lg transition-all"
                style={{ fontFamily: "'Gmarket Sans', sans-serif" }}
              >
                <BookOpen className="w-5 h-5" />
                프로그램북 만들기
              </motion.button>
            </motion.div>
          </div>
        </div>
      </section>

      {/* 푸터 */}
      <footer className="bg-[oklch(0.22_0.01_240)] py-12">
        <div className="container text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="w-8 h-8 rounded-full bg-[oklch(0.32_0.07_210)] flex items-center justify-center">
              <span className="text-white text-xs font-bold" style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>부</span>
            </div>
            <span className="font-bold text-white text-sm" style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>
              부산 숨은 여행 프로그램북
            </span>
          </div>
          <p className="text-white/40 text-sm">
            부산의 진짜 매력을 당신의 취향으로 발견하세요
          </p>
        </div>
      </footer>
    </div>
  );
}
