/* =============================================================
   Result.tsx — 추천 결과 및 프로그램북 페이지
   Design: 해무(海霧) 모더니즘
   - 추천 장소 카드 그리드
   - 시간대별 여행 일정표
   - 인쇄/저장 기능
   ============================================================= */

import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import {
  MapPin, Clock, Star, ChevronLeft, Printer, Download,
  RefreshCw, Tag, Navigation, Sparkles, BookOpen, Map
} from "lucide-react";
import {
  getRecommendations, generateItinerary,
  type UserPreferences, type Spot, type ItineraryItem
} from "@/lib/spots-data";

const categoryColors: Record<string, string> = {
  "자연": "bg-emerald-100 text-emerald-700",
  "문화예술": "bg-purple-100 text-purple-700",
  "역사": "bg-amber-100 text-amber-700",
  "음식": "bg-orange-100 text-orange-700",
  "카페": "bg-rose-100 text-rose-700",
  "액티비티": "bg-blue-100 text-blue-700",
};

const moodLabels: Record<string, string> = {
  "힐링": "🌊 힐링",
  "감성": "🎨 감성",
  "모험": "⛰️ 모험",
  "로맨틱": "🌅 로맨틱",
  "역사탐방": "🏛️ 역사탐방",
  "미식": "🍜 미식",
};

const hiddenScoreStars = (score: number) =>
  Array.from({ length: 5 }, (_, i) => i < score ? "★" : "☆").join("");

function SpotCard({ spot, index }: { spot: Spot; index: number }) {
  const [expanded, setExpanded] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.08, duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
      className="busan-card overflow-hidden"
    >
      {/* 이미지 */}
      <div className="relative h-44 overflow-hidden">
        <img
          src={spot.image}
          alt={spot.name}
          className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />

        {/* 숨겨진 점수 */}
        <div className="absolute top-3 right-3">
          <div className="hidden-score-badge">
            비밀 {hiddenScoreStars(spot.hiddenScore)}
          </div>
        </div>

        {/* 지역 배지 */}
        <div className="absolute bottom-3 left-3">
          <div className="flex items-center gap-1 bg-white/20 backdrop-blur-sm rounded-full px-2.5 py-1">
            <MapPin className="w-3 h-3 text-white" />
            <span className="text-white text-xs font-medium">{spot.district}</span>
          </div>
        </div>
      </div>

      {/* 콘텐츠 */}
      <div className="p-5">
        <div className="flex items-start justify-between gap-2 mb-2">
          <h3 className="font-bold text-[oklch(0.22_0.01_240)] text-lg leading-tight"
            style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>
            {spot.name}
          </h3>
          <div className="flex gap-1 flex-shrink-0">
            {spot.categories.slice(0, 1).map(cat => (
              <span key={cat} className={`text-xs px-2 py-0.5 rounded-full font-medium ${categoryColors[cat] || "bg-gray-100 text-gray-600"}`}>
                {cat}
              </span>
            ))}
          </div>
        </div>

        <p className="text-[oklch(0.52_0.02_200)] text-sm leading-relaxed mb-3">
          {spot.description}
        </p>

        <div className="flex items-center gap-4 text-xs text-[oklch(0.52_0.02_200)] mb-3">
          <span className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5" />
            {spot.duration}
          </span>
          <span className="flex items-center gap-1">
            <Navigation className="w-3.5 h-3.5" />
            {spot.difficulty}
          </span>
          <span className="flex items-center gap-1">
            <Star className="w-3.5 h-3.5 text-amber-400" />
            {spot.bestTime}
          </span>
        </div>

        {/* 무드 태그 */}
        <div className="flex flex-wrap gap-1.5 mb-3">
          {spot.moods.map(mood => (
            <span key={mood} className="text-xs bg-[oklch(0.97_0.01_80)] text-[oklch(0.32_0.07_210)] px-2 py-0.5 rounded-full border border-[oklch(0.87_0.02_80)]">
              {moodLabels[mood] || mood}
            </span>
          ))}
        </div>

        {/* 꿀팁 토글 */}
        <button
          onClick={() => setExpanded(!expanded)}
          className="text-xs text-[oklch(0.32_0.07_210)] font-medium flex items-center gap-1 hover:underline"
        >
          <Tag className="w-3.5 h-3.5" />
          현지인 꿀팁 {expanded ? "접기" : "보기"}
        </button>

        <AnimatePresence>
          {expanded && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.25 }}
              className="overflow-hidden"
            >
              <div className="mt-3 p-3 bg-[oklch(0.32_0.07_210)]/5 rounded-lg border-l-2 border-[oklch(0.32_0.07_210)]">
                <p className="text-xs text-[oklch(0.32_0.07_210)] leading-relaxed">
                  💡 {spot.tips}
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}

function ItineraryCard({ item, index }: { item: ItineraryItem; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.1, duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
      className="flex gap-4"
    >
      {/* 타임라인 */}
      <div className="flex flex-col items-center">
        <div className="w-12 h-12 rounded-full bg-[oklch(0.32_0.07_210)] flex items-center justify-center flex-shrink-0 shadow-md">
          <span className="text-white text-xs font-bold" style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>
            {item.time}
          </span>
        </div>
        {index < 5 && <div className="w-0.5 h-full bg-[oklch(0.87_0.02_80)] mt-2 min-h-[2rem]" />}
      </div>

      {/* 카드 */}
      <div className="program-book-card flex-1 p-4 mb-4">
        <div className="flex items-start gap-3">
          <img
            src={item.spot.image}
            alt={item.spot.name}
            className="w-16 h-16 rounded-xl object-cover flex-shrink-0"
          />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs text-[oklch(0.58_0.12_45)] font-bold"
                style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>
                {item.activity}
              </span>
            </div>
            <h4 className="font-bold text-[oklch(0.22_0.01_240)] text-base mb-1"
              style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>
              {item.spot.name}
            </h4>
            <p className="text-xs text-[oklch(0.52_0.02_200)] flex items-center gap-1">
              <MapPin className="w-3 h-3" />
              {item.spot.district} · {item.spot.duration}
            </p>
            <p className="text-xs text-[oklch(0.32_0.07_210)] mt-1.5 bg-[oklch(0.32_0.07_210)]/5 rounded-md px-2 py-1">
              💡 {item.tip}
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

export default function Result() {
  const [, navigate] = useLocation();
  const [prefs, setPrefs] = useState<UserPreferences | null>(null);
  const [recommendations, setRecommendations] = useState<Spot[]>([]);
  const [itinerary, setItinerary] = useState<ItineraryItem[]>([]);
  const [activeTab, setActiveTab] = useState<"spots" | "program">("spots");
  const printRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const stored = sessionStorage.getItem("busan-quiz-result");
    if (!stored) {
      navigate("/quiz");
      return;
    }
    const p: UserPreferences = JSON.parse(stored);
    setPrefs(p);
    const recs = getRecommendations(p);
    setRecommendations(recs);
    setItinerary(generateItinerary(recs, p.duration));
  }, []);

  const handlePrint = () => {
    window.print();
  };

  const handleRetry = () => {
    sessionStorage.removeItem("busan-quiz-result");
    navigate("/quiz");
  };

  if (!prefs) return null;

  const styleLabels: Record<string, string> = {
    "힐링": "힐링 여행자",
    "감성": "감성 여행자",
    "모험": "모험 여행자",
    "로맨틱": "로맨틱 여행자",
    "역사탐방": "역사 탐험가",
    "미식": "미식 여행자",
  };

  const companionLabels: Record<string, string> = {
    "solo": "혼자",
    "couple": "연인과 함께",
    "friends": "친구들과",
    "family": "가족과 함께",
  };

  return (
    <div className="min-h-screen bg-[oklch(0.97_0.01_80)]">
      {/* 헤더 */}
      <header className="bg-white border-b border-[oklch(0.87_0.02_80)] sticky top-0 z-40">
        <div className="container py-4 flex items-center justify-between">
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-1.5 text-[oklch(0.52_0.02_200)] hover:text-[oklch(0.32_0.07_210)] transition-colors text-sm font-medium"
          >
            <ChevronLeft className="w-4 h-4" />
            홈으로
          </button>

          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-full bg-[oklch(0.32_0.07_210)] flex items-center justify-center">
              <span className="text-white text-[10px] font-bold" style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>부</span>
            </div>
            <span className="text-[oklch(0.32_0.07_210)] font-bold text-sm" style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>
              나의 부산 프로그램북
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleRetry}
              className="flex items-center gap-1.5 text-[oklch(0.52_0.02_200)] hover:text-[oklch(0.32_0.07_210)] transition-colors text-sm"
            >
              <RefreshCw className="w-4 h-4" />
              다시하기
            </button>
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 bg-[oklch(0.32_0.07_210)] text-white text-sm font-medium px-4 py-2 rounded-full hover:bg-[oklch(0.45_0.08_210)] transition-colors"
            >
              <Printer className="w-4 h-4" />
              인쇄
            </button>
          </div>
        </div>
      </header>

      <div ref={printRef}>
        {/* 결과 헤더 배너 */}
        <section className="bg-[oklch(0.32_0.07_210)] py-12">
          <div className="container">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: [0.23, 1, 0.32, 1] }}
              className="text-center"
            >
              <div className="inline-flex items-center gap-2 bg-white/10 rounded-full px-4 py-1.5 mb-4">
                <Sparkles className="w-3.5 h-3.5 text-[oklch(0.72_0.09_45)]" />
                <span className="text-white/80 text-xs">맞춤 추천 완료</span>
              </div>
              <h1 className="text-3xl md:text-4xl font-bold text-white mb-3"
                style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>
                {styleLabels[prefs.travelStyle] || prefs.travelStyle}의<br />
                부산 숨은 여행 코스
              </h1>
              <p className="text-white/70 text-base" style={{ fontFamily: "'Noto Serif KR', serif" }}>
                {companionLabels[prefs.companion]} · {prefs.duration} 일정 · {recommendations.length}곳 추천
              </p>

              {/* 선택된 카테고리 태그 */}
              {prefs.categories.length > 0 && (
                <div className="flex flex-wrap justify-center gap-2 mt-4">
                  {prefs.categories.map(cat => (
                    <span key={cat} className="bg-white/10 text-white/80 text-xs px-3 py-1 rounded-full border border-white/20">
                      {cat}
                    </span>
                  ))}
                </div>
              )}
            </motion.div>
          </div>
        </section>

        {/* 탭 네비게이션 */}
        <div className="bg-white border-b border-[oklch(0.87_0.02_80)] sticky top-[65px] z-30">
          <div className="container">
            <div className="flex gap-0">
              <button
                onClick={() => setActiveTab("spots")}
                className={`flex items-center gap-2 px-6 py-4 text-sm font-bold border-b-2 transition-colors ${
                  activeTab === "spots"
                    ? "border-[oklch(0.32_0.07_210)] text-[oklch(0.32_0.07_210)]"
                    : "border-transparent text-[oklch(0.52_0.02_200)] hover:text-[oklch(0.32_0.07_210)]"
                }`}
                style={{ fontFamily: "'Gmarket Sans', sans-serif" }}
              >
                <Map className="w-4 h-4" />
                추천 명소 ({recommendations.length})
              </button>
              <button
                onClick={() => setActiveTab("program")}
                className={`flex items-center gap-2 px-6 py-4 text-sm font-bold border-b-2 transition-colors ${
                  activeTab === "program"
                    ? "border-[oklch(0.32_0.07_210)] text-[oklch(0.32_0.07_210)]"
                    : "border-transparent text-[oklch(0.52_0.02_200)] hover:text-[oklch(0.32_0.07_210)]"
                }`}
                style={{ fontFamily: "'Gmarket Sans', sans-serif" }}
              >
                <BookOpen className="w-4 h-4" />
                프로그램북
              </button>
            </div>
          </div>
        </div>

        <div className="container py-10">
          <AnimatePresence mode="wait">
            {/* 추천 명소 탭 */}
            {activeTab === "spots" && (
              <motion.div
                key="spots"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3 }}
              >
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {recommendations.map((spot, i) => (
                    <SpotCard key={spot.id} spot={spot} index={i} />
                  ))}
                </div>

                {/* 하단 CTA */}
                <div className="mt-10 text-center">
                  <p className="text-[oklch(0.52_0.02_200)] text-sm mb-4"
                    style={{ fontFamily: "'Noto Serif KR', serif" }}>
                    이 장소들로 구성된 시간표를 확인해보세요
                  </p>
                  <button
                    onClick={() => setActiveTab("program")}
                    className="inline-flex items-center gap-2 bg-[oklch(0.58_0.12_45)] text-white font-bold px-8 py-3 rounded-full transition-all hover:bg-[oklch(0.52_0.10_45)]"
                    style={{ fontFamily: "'Gmarket Sans', sans-serif" }}
                  >
                    <BookOpen className="w-4 h-4" />
                    프로그램북 보기
                  </button>
                </div>
              </motion.div>
            )}

            {/* 프로그램북 탭 */}
            {activeTab === "program" && (
              <motion.div
                key="program"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3 }}
              >
                <div className="max-w-2xl mx-auto">
                  {/* 프로그램북 헤더 */}
                  <div className="bg-white rounded-2xl p-6 mb-6 border border-[oklch(0.87_0.02_80)] text-center">
                    <div className="w-16 h-16 rounded-full bg-[oklch(0.32_0.07_210)]/10 flex items-center justify-center mx-auto mb-3">
                      <BookOpen className="w-8 h-8 text-[oklch(0.32_0.07_210)]" />
                    </div>
                    <h2 className="text-2xl font-bold text-[oklch(0.22_0.01_240)] mb-1"
                      style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>
                      나의 부산 여행 일정
                    </h2>
                    <p className="text-[oklch(0.52_0.02_200)] text-sm">
                      {prefs.duration} · {companionLabels[prefs.companion]} · {styleLabels[prefs.travelStyle]}
                    </p>
                  </div>

                  {/* 일정 타임라인 */}
                  <div className="space-y-0">
                    {itinerary.map((item, i) => (
                      <ItineraryCard key={item.spot.id} item={item} index={i} />
                    ))}
                  </div>

                  {/* 여행 팁 섹션 */}
                  <div className="mt-8 bg-[oklch(0.32_0.07_210)] rounded-2xl p-6 text-white">
                    <h3 className="font-bold text-lg mb-4 flex items-center gap-2"
                      style={{ fontFamily: "'Gmarket Sans', sans-serif" }}>
                      <Sparkles className="w-5 h-5 text-[oklch(0.72_0.09_45)]" />
                      부산 여행 필수 팁
                    </h3>
                    <div className="space-y-2.5">
                      {[
                        "부산 도시철도 1일권(5,000원)으로 대부분 이동 가능",
                        "영도·서구 지역은 마을버스가 편리합니다",
                        "부산 맛집은 평일 방문 시 대기 없이 즐길 수 있어요",
                        "일몰 명소는 30분 전에 미리 도착하세요",
                      ].map((tip, i) => (
                        <div key={i} className="flex items-start gap-2">
                          <div className="w-1.5 h-1.5 rounded-full bg-[oklch(0.72_0.09_45)] mt-1.5 flex-shrink-0" />
                          <p className="text-white/80 text-sm">{tip}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* 인쇄 버튼 */}
                  <div className="mt-6 flex gap-3 justify-center">
                    <button
                      onClick={handlePrint}
                      className="flex items-center gap-2 bg-[oklch(0.32_0.07_210)] text-white font-bold px-6 py-3 rounded-full hover:bg-[oklch(0.45_0.08_210)] transition-colors"
                      style={{ fontFamily: "'Gmarket Sans', sans-serif" }}
                    >
                      <Printer className="w-4 h-4" />
                      인쇄하기
                    </button>
                    <button
                      onClick={handleRetry}
                      className="flex items-center gap-2 border-2 border-[oklch(0.87_0.02_80)] text-[oklch(0.52_0.02_200)] font-bold px-6 py-3 rounded-full hover:border-[oklch(0.32_0.07_210)] hover:text-[oklch(0.32_0.07_210)] transition-colors"
                      style={{ fontFamily: "'Gmarket Sans', sans-serif" }}
                    >
                      <RefreshCw className="w-4 h-4" />
                      다시 만들기
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* 인쇄 스타일 */}
      <style>{`
        @media print {
          header, nav, .sticky { display: none !important; }
          body { background: white !important; }
          .busan-card { box-shadow: none !important; border: 1px solid #eee !important; }
        }
      `}</style>
    </div>
  );
}
