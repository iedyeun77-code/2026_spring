# 부산 숨은 여행 프로그램북 — 디자인 아이디어

## 아이디어 1: 해항도시 인디고 (Indigo Port City)

<response>
<text>
**Design Movement**: 한국 근현대 항구 도시 미학 + 일본 인디고 염색(藍染) 감성

**Core Principles**:
- 부산의 바다와 항구를 상징하는 깊은 인디고 블루 팔레트
- 손글씨 느낌의 타이포그래피로 여행 일기장 감성
- 비대칭 레이아웃으로 골목길 탐험의 우연성 표현
- 거친 종이 질감 텍스처로 아날로그 프로그램북 느낌

**Color Philosophy**:
- 주색: 인디고 블루 (#1B3A6B) — 부산 바다의 깊이
- 보조색: 크림 화이트 (#F5F0E8) — 오래된 종이
- 강조색: 산호 오렌지 (#E8623A) — 부산 일몰
- 중립색: 슬레이트 그레이 (#6B7280)

**Layout Paradigm**:
- 세로 스크롤 여행 일지 형식
- 카드가 비틀어진 각도로 배치 (마치 사진을 붙인 듯)
- 왼쪽 사이드바에 진행 상태 표시

**Signature Elements**:
- 손그림 지도 일러스트레이션
- 도장(스탬프) 스타일 카테고리 배지
- 찢어진 종이 엣지 구분선

**Interaction Philosophy**:
- 취향 선택 시 도장 찍히는 애니메이션
- 프로그램북 생성 시 종이 넘기는 전환 효과

**Animation**:
- 카드 등장: 살짝 기울어진 채로 fade-in (200ms)
- 도장 선택: scale 0.95→1.05→1.0 (160ms)
- 페이지 전환: 종이 슬라이드 (300ms)

**Typography System**:
- 헤딩: Noto Serif KR (세리프, 여행 일기 감성)
- 본문: Noto Sans KR (가독성)
- 영문 강조: Playfair Display Italic
</text>
<probability>0.08</probability>
</response>

---

## 아이디어 2: 산복도로 노스탤지어 (Sanbok-doro Nostalgia)

<response>
<text>
**Design Movement**: 한국 1960-80년대 레트로 + 현대 편집 디자인 (Editorial Retro)

**Core Principles**:
- 부산 산복도로의 색바랜 골목 미학
- 신문/잡지 편집 레이아웃으로 정보 밀도 높게 표현
- 노이즈 그레인 텍스처로 필름 사진 감성
- 강렬한 타이포그래피 대비

**Color Philosophy**:
- 주색: 머스타드 옐로우 (#D4A017) — 산복도로 오래된 집벽
- 보조색: 오프화이트 (#F2EDE4)
- 강조색: 버밀리온 레드 (#C0392B) — 부산 항구 등대
- 다크: 차콜 (#2C2C2C)

**Layout Paradigm**:
- 신문 그리드 (불규칙 칼럼 배치)
- 큰 헤드라인 텍스트가 레이아웃을 지배
- 사진과 텍스트가 겹치는 오버랩 구성

**Signature Elements**:
- 필름 그레인 오버레이
- 빈티지 우표 스타일 장소 카드
- 굵은 선 구분자 (신문 스타일)

**Interaction Philosophy**:
- 선택 시 타자기 타이핑 효과
- 스크롤 시 시차 효과 (parallax)

**Animation**:
- 텍스트 등장: 타자기 타이핑 (글자별 30ms)
- 카드 호버: 그림자 깊어짐 + 살짝 상승 (150ms)
- 페이지 전환: 수평 슬라이드 (250ms)

**Typography System**:
- 헤딩: Black Han Sans (굵고 강렬)
- 본문: Noto Sans KR Regular
- 숫자/영문: Space Grotesk
</text>
<probability>0.07</probability>
</response>

---

## 아이디어 3: 해무(海霧) 모더니즘 (Sea Fog Modernism) ← 선택

<response>
<text>
**Design Movement**: 한국 미니멀리즘 + 해안 도시 안개 미학 (Coastal Mist Modernism)

**Core Principles**:
- 부산 새벽 바다의 안개처럼 부드럽고 몽환적인 레이어
- 여백을 적극 활용한 숨 쉬는 레이아웃
- 섬세한 그라데이션과 반투명 유리 효과 (Glassmorphism 절제)
- 타이포그래피 주도 계층 구조

**Color Philosophy**:
- 배경: 해무 화이트 (#F8F7F5) — 새벽 안개
- 주색: 심해 틸 (#1A4A5C) — 부산 심해
- 보조색: 모래 베이지 (#E8DDD0) — 해변 모래
- 강조색: 테라코타 (#C4704A) — 부산 기와지붕
- 포인트: 민트 그린 (#4A9B8E) — 해초

**Layout Paradigm**:
- 비대칭 2단 레이아웃 (왼쪽 좁은 네비게이션, 오른쪽 넓은 콘텐츠)
- 설문 단계는 전체화면 몰입형 (full-bleed)
- 프로그램북은 잡지 스프레드 형식

**Signature Elements**:
- 물결 모양 SVG 구분선
- 원형 이미지 클리핑 (항구 포트홀 연상)
- 미세한 점선 패턴 배경

**Interaction Philosophy**:
- 취향 선택: 부드러운 물결 ripple 효과
- 단계 진행: 수평 슬라이드 + 페이드
- 프로그램북: 책 펼치는 3D 전환

**Animation**:
- 요소 등장: translateY(20px)→0 + opacity 0→1 (300ms, cubic-bezier(0.23,1,0.32,1))
- 카드 호버: scale(1.02) + 그림자 확장 (200ms)
- 선택 확인: 물결 ripple (400ms)
- 스텝 전환: 수평 슬라이드 (350ms ease-in-out)

**Typography System**:
- 헤딩: Gmarket Sans Bold (한국적이면서 모던)
- 서브헤딩: Noto Serif KR Medium
- 본문: Noto Sans KR Regular
- 숫자/영문 강조: DM Serif Display
</text>
<probability>0.09</probability>
</response>
